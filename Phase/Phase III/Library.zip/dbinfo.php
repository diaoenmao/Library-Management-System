<?php

$user = 'root';
$pass = '';
$host = 'localhost';   
$database = 'library';
date_default_timezone_set('America/New_York');
?>